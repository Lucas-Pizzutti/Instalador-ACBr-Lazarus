# ACBrInstaller 2.5 — Beta

Instalador gratuito de componentes ACBr para Lazarus no Windows, com suporte a IDEs de 32 e 64 bits. Instala na IDE principal selecionada, reconstruindo seu executável e registrando os pacotes no perfil escolhido.

Projeto independente, sem vínculo oficial com o Projeto ACBr ou o Lazarus.

## Requisitos

- Windows com .NET Framework 4.8.
- Lazarus completo com fontes e compilador FPC correspondente à arquitetura da IDE.
- Fontes ACBr completos, contendo Fontes e Pacotes/Lazarus.
- Permissão de gravação nas pastas selecionadas e espaço para backup.

## Como usar

1. Extraia todos os arquivos do ZIP numa pasta. Mantenha ACBrInstaller.exe.config junto do executável.
2. Abra o Lazarus uma vez, conclua sua configuração inicial e feche a IDE antes de usar o instalador.
3. Execute ACBrInstaller.exe e selecione a pasta do Lazarus, a raiz dos fontes ACBr e o perfil usado normalmente pela IDE.
4. O perfil costuma ficar em %LOCALAPPDATA%\lazarus e deve conter environmentoptions.xml. Se o atalho usa --primary-config-path, selecione a pasta indicada nele.
5. Selecione uma pasta separada para backups e logs. Informe também os fontes de outros componentes já instalados, quando solicitado.
6. Analise os pacotes, selecione os componentes desejados, revise e simule. Se houver pacotes registrados, escolha Atualizar ou Manter conforme sua necessidade.
7. Mantenha o backup ativado e confirme a instalação. Aguarde o resultado.
8. Ao concluir, use Abrir Lazarus e finalizar. Confira a paleta de componentes e compile um projeto de teste.

Mantenha a pasta dos fontes ACBr no mesmo local após instalar.

## Backup e problemas

O backup vem ativado. Desativá-lo impede a recuperação automática em caso de falha. Não feche o programa à força durante a instalação.

Se ocorrer um erro, consulte os logs na pasta execucao-... dentro da pasta de backups escolhida. O destino padrão é %LOCALAPPDATA%\ACBrInstaller\Backups. Use Restaurar backup, quando necessário e disponível.

Ao relatar um problema, informe a versão do Windows, do Lazarus, do FPC e a arquitetura. Anexe instalacao.log após conferir se contém dados pessoais.

## Limites desta versão

Versão beta: valide primeiro em uma VM ou numa instalação de teste. A compatibilidade com todas as versões e combinações de componentes ainda não foi validada.

Não inclui ACBr, Lazarus, compilador, DLLs fiscais, schemas ou certificados. Esses arquivos e as credenciais da aplicação devem ser obtidos/configurados separadamente.

## Licença

O código próprio do instalador é disponibilizado sob a licença MIT, incluída em LICENSE.txt. O programa é distribuído gratuitamente e sem garantia, conforme a licença.

ACBr, Lazarus e demais componentes mantêm suas próprias licenças; a licença do instalador não substitui as deles. Os fontes do instalador não estão incluídos neste pacote.

## Correção 2.4.1

A simulação e a instalação são bloqueadas quando o perfil não contém environmentoptions.xml válido com a estrutura CONFIG/EnvironmentOptions. A mensagem orienta abrir, configurar e fechar o Lazarus antes de continuar. Nenhum perfil é criado pelo bloqueio. Essa verificação não identifica automaticamente qual perfil é utilizado pelo atalho; selecione o perfil correto.

## Descoberta automática de pacotes — 2.4.2

Ao analisar, o instalador consulta os pacotes registrados e os vínculos do perfil escolhido, pesquisa LPKs na pasta do Lazarus e procura pacotes ausentes em onlinepackagemanager\packages do perfil. Pacotes como PowerPDF são identificados sem preencher a pasta de extras quando seus fontes estão disponíveis nesses locais. Somente os pacotes registrados e suas dependências são incorporados por essa descoberta; não instala todos os downloads. Pacotes ambíguos ou com fontes ausentes continuam bloqueando a reconstrução. Fontes armazenados em outros locais podem exigir informar a pasta de extras. Os fontes dos pacotes existentes também entram no backup quando ele está ativado.

O requisito recomendado para esta versão beta é Windows de 64 bits. Windows de 32 bits não foi validado com sucesso para a reconstrução completa da IDE. Lazarus de 32 bits em Windows de 64 bits é uma combinação diferente.

## Correções 2.4.3

Identifica a raiz de componentes registrados com LPKs em subpastas e fontes relativos em pastas superiores próximas, como UserControl\package\lazarus e UserControl\source. Configurações vazias de execução que só controlam a exibição de mensagens não são confundidas com comandos. Comandos externos reais continuam bloqueados. Erros de pacote mostram o LPK, a raiz identificada e o motivo. O executável foi compilado e a leitura dos três LPKs do UserControl foi validada sem executar instalação na IDE.

## Verificação de componentes existentes — 2.5

Após Analisar pacotes, uma tela mostra os componentes registrados no perfil selecionado e suas dependências, com situação, LPK e explicação. Encontrado significa que os fontes, dependências e validações conhecidas passaram; não garante a compilação real.

Para corrigir fontes ausentes ou uma raiz inadequada, selecione o item e clique em Indicar pasta dos fontes. Escolha a raiz do componente, contendo seus LPKs e fontes. O programa exige o nome declarado do pacote solicitado, reanalisa e permite pastas diferentes para componentes diferentes. As escolhas são mantidas durante a sessão, são incluídas na validação da simulação e não alteram o perfil na etapa de verificação. A mudança da IDE ou do perfil limpa essas associações ao reanalisar.

Continuar fica bloqueado enquanto existirem componentes ou dependências pendentes. Use Voltar para ajustar o ambiente. Mantenha o backup ativado. Não é oferecida garantia de compatibilidade universal. Esta atualização é do executável C#; o projeto Pascal independente não foi atualizado com essa tela.
